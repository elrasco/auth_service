# smallfish_auth

a [Sails](http://sailsjs.org) application
