/**
 * User_roleController
 *
 * @description :: Server-side logic for managing User_role
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {};

